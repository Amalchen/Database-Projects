-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2017 at 07:26 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--
CREATE DATABASE IF NOT EXISTS `restaurant` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `restaurant`;

-- --------------------------------------------------------

# Privileges for `adminoras`@`localhost`

GRANT SELECT, INSERT, UPDATE, DELETE ON *.* TO 'adminoras'@'localhost';


# Privileges for `helot`@`localhost`

GRANT SELECT, INSERT, UPDATE, DELETE ON *.* TO 'helot'@'localhost';

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(37) NOT NULL,
  `details` text NOT NULL,
  `price` float(7,2) NOT NULL,
  `menuID` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `details`, `price`, `menuID`) VALUES
(26, 'Caprese mezzaluna', 'Half moons of whipped buffalo ricotta & spinach in tomato sauce with baby mozzarella & basil', 11.95, 'Pasta'),
(27, 'Raphael\'s octopus ravioli ', 'Octopus & squid-ink pasta parcels in a rich shellfish & tomato sauce, topped with hand-picked Cornish crab', 14.55, 'Pasta'),
(28, 'Cannelloni al forno', 'Nettle, ricotta & chard-filled pasta baked with sweet leeks, tomato, basil & creme fraiche', 12.95, 'Pasta'),
(29, 'Primavera ravioli', 'Buffalo ricotta & black pepper pasta parcels in a lemony butter sauce with peas, mint & pea shoots', 12.95, 'Pasta'),
(30, 'Oxtail lasagne', 'Herby 12-hour slow-cooked oxtail & Chianti ragu layered with pasta, bechamel, mozzarella & Parmesan', 13.95, 'Pasta'),
(31, 'Silky penne carbonara', 'Sweet tender leeks with golden smoky pancetta, cracked black pepper & Parmesan', 6.55, 'Pasta'),
(32, 'Dimitris\' tagliatelle Bolognese', 'Amazing pork & beef slow cooked with red wine, topped with pangrattato & Parmesan', 6.55, 'Pasta'),
(33, 'Spicy sausage pappardelle', 'Free-range pork & fennel ragu with Cobble Lane \'nduja, Calabrian chilli & pecorino', 6.95, 'Pasta'),
(34, 'Gnocchi Sorrentina', 'Organic potato gnocchi in slow-roasted tomato sauce with garlic, basil & baby mozzarella', 6.55, 'Pasta'),
(35, 'Greek snail spaghetti', 'With tomatoes, chilli, fennel, capers, white wine & garlic, topped with lemon zest & extra virgin olive oil', 7.55, 'Pasta'),
(36, 'Veggie tagliatelle Bolognese', 'Tomato, lentil & porcini ragu with garlic, pangrattato & veggie Parmesan', 5.55, 'Pasta'),
(37, 'Prawn linguine', 'Garlicky prawns & Scottish langoustine tails with tomatoes, fennel, saffron, fresh chilli & rocket', 7.55, 'Pasta'),
(38, 'Broccoli Cheddar Soup', 'Hot, creamy, cheesy and delicious, our Broccoli Cheddar is great comfort food even when you don\'t need comforting.', 6.79, 'Soup'),
(39, 'Creamy Roasted Tomato Basil Soup', 'A Creamy Roasted Tomato Basil Soup full of incredible flavours, naturally thickened with no need for cream cheese or heavy creams.', 6.79, 'Soup'),
(40, 'Irish Beef Stew', 'Beef stew recipe made with beef, garlic, stock, Irish Guinness beer, red wine, potatoes, carrots, and onions. An excellent, hearty stew.\r\n', 6.79, 'Soup'),
(41, 'French Onion Soup', 'Classic simple French onion soup recipe, with beef stock base, slow-cooked caramelized onions, French bread, gruyere and Parmesan cheese.', 6.79, 'Soup'),
(42, 'Albondigas Soup', 'Classic Mexican soup made with meatballs (albondigas), green beens, onions, and chicken stock.', 6.79, 'Soup'),
(43, 'Tortilla Soup', 'Crispy fried strips of corn tortillas in a tomato-based Mexican soup with chicken stock, chiles, avocado, Jack cheese, cilantro and lime.', 6.79, 'Soup'),
(44, 'Carrot Ginger Soup', 'Smooth carrot soup with ginger, orange and chicken stock.', 6.79, 'Soup'),
(45, 'Minestrone Soup', 'Minestrone soup with cannellini beans, chicken stock, cabbage, potato, zucchini, carrots, plum tomatoes, and Parmesan cheese.', 6.79, 'Soup'),
(46, 'Bombay Sapphire', 'Spirit', 3.25, 'Drinks'),
(47, 'Jack Daniels', 'Spirit', 3.50, 'Drinks'),
(48, 'Malibu', 'Spirit', 3.50, 'Drinks'),
(49, 'Lemonade', 'Homemade', 1.60, 'Drinks'),
(50, 'Adult\'s lemonade', 'Cocktail. Vodka and limoncello with our handmade lemonade.\r\n', 5.95, 'Drinks'),
(51, 'Earl Grey Tea', 'Tea', 2.25, 'Drinks'),
(52, 'White chocolate cheesecake', 'A dark chocolate cookie crumble crust filled with thick white chocolate cheesecake. Served with your choice of strawberry, peanut butter or caramel sauce. Topped with whipped cream and chocolate shavings. (1020-1180 cal)', 7.99, 'Dessert'),
(53, 'Brownie pops', 'Brownies battered, golden fried and rolled in cinnamon sugar. Served with caramel sauce for dipping. (780 cal)', 6.99, 'Dessert'),
(54, 'Funnel cake fries', 'Golden fried strips of funnel cake topped with cinnamon sugar. Served warm with French Vanilla ice cream and choice of strawberry, peanut butter, chocolate, or caramel sauce. (750-810 cal)', 6.99, 'Dessert'),
(55, 'Messy cookie sandwich', 'THIS IS ONE SANDWICH YOU CAN\'T EAT WITH YOUR HANDS! French Vanilla ice cream placed between two giant warm chocolate chip cookies. Topped with chocolate and thick caramel sauce. (1680 cal)', 7.99, 'Dessert'),
(56, 'Go nuts donuts', 'Warm donuts stuffed with Nutella and sprinkled with icing sugar. Served with your choice of peanut butter sauce or caramel sauce for dipping. (1110-1330 cal)', 8.49, 'Dessert'),
(57, 'Dessert treat trio', 'GREAT FOR SHARING! Funnel Cake Fries, Brownie Pops and two Go Nuts Donuts. (1450-1730 cal)', 10.99, 'Dessert'),
(59, 'Makaronia me Kima', 'Cooked by Greek singer Sakis Rouvas himself (ONLY FOR TODAY)', 99.99, 'specialty');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int(11) NOT NULL,
  `menuID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `partyNumber` int(11) NOT NULL,
  `tableNumber` int(11) NOT NULL,
  `customerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `date`, `time`, `partyNumber`, `tableNumber`, `customerID`) VALUES
(1, '2017-07-11', '15:30:00', 4, 1, 1),
(2, '2017-07-18', '15:30:00', 4, 2, 4),
(3, '2017-07-18', '15:30:00', 7, 8, 8),
(8, '2017-07-18', '15:30:00', 7, 10, 8),
(35, '2017-06-28', '20:00:00', 4, 2, 4),
(37, '2017-06-26', '13:30:00', 10, 2, 5),
(38, '2017-06-26', '13:30:00', 10, 3, 5),
(39, '2017-06-26', '13:30:00', 10, 4, 5),
(40, '2017-06-26', '13:30:00', 10, 5, 5),
(45, '2017-06-26', '12:00:00', 9, 1, 4),
(46, '2017-06-26', '12:00:00', 9, 2, 4),
(47, '2017-06-26', '12:00:00', 9, 3, 4),
(48, '2017-06-26', '12:00:00', 9, 4, 4),
(49, '2017-07-11', '12:00:00', 16, 1, 4),
(50, '2017-07-11', '12:00:00', 16, 2, 4),
(51, '2017-07-11', '12:00:00', 16, 3, 4),
(52, '2017-07-11', '12:00:00', 16, 4, 4),
(53, '2017-07-11', '12:00:00', 16, 5, 4),
(54, '2017-07-11', '12:00:00', 16, 6, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `tableNumber` int(11) NOT NULL,
  `seat` tinyint(11) NOT NULL,
  `details` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`tableNumber`, `seat`, `details`) VALUES
(1, 4, 'non-smokers'),
(2, 4, 'non-smokers'),
(3, 4, 'non-smokers'),
(4, 4, 'non-smokers'),
(5, 6, 'non-smokers'),
(6, 6, 'non-smokers'),
(7, 4, 'smokers'),
(8, 4, 'smokers'),
(9, 6, 'smokers'),
(10, 6, 'smokers');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `firstname` varchar(37) NOT NULL,
  `surname` varchar(37) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `firstname`, `surname`) VALUES
(1, 'test', '32250170a0dca92d53ec9624f336ca24', 'John', 'Smith'),
(2, 'test2', '654321', 'John2', 'Smith2'),
(3, 'Rafail', '32250170a0dca92d53ec9624f336ca24', 'Raphael', 'Karkanis'),
(4, 'test3', '32250170a0dca92d53ec9624f336ca24', 'Arxi', 'Didaskalos'),
(5, 'Arni', '32250170a0dca92d53ec9624f336ca24', 'Mpampis', 'Stokas'),
(6, 'bobas', '32250170a0dca92d53ec9624f336ca24', 'Arxigos', 'Purablos'),
(7, 'test4', '32250170a0dca92d53ec9624f336ca24', 'test4', 'test4'),
(8, 'admin', '32250170a0dca92d53ec9624f336ca24', 'Luke', 'Skywalker');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `menuIDConstraint` (`menuID`),
  ADD KEY `customerIDConstraint2` (`customerID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tableNumberConstraint` (`tableNumber`),
  ADD KEY `customerIDConstraint` (`customerID`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`tableNumber`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `tableNumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `customerIDConstraint2` FOREIGN KEY (`customerID`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `menuIDConstraint` FOREIGN KEY (`menuID`) REFERENCES `menu` (`id`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `customerIDConstraint` FOREIGN KEY (`customerID`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tableNumberConstraint` FOREIGN KEY (`tableNumber`) REFERENCES `tables` (`tableNumber`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
